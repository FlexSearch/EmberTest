export default Ember.Route.extend({
    model: function () { return [{
      IndexName: "Tomster",
      ProfileName: "http://emberjs.com/images/about/ember-productivity-sm.png"
    }, {
      IndexName: "Eiffel Tower",
      ProfileName: "http://emberjs.com/images/about/ember-structure-sm.png"
    }];
  }
});
